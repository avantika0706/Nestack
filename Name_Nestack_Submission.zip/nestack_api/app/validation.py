"""Input validation. Raises ValidationError -> 400."""
import re

USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")


class ValidationError(Exception):
    pass


def _string(data, field, min_len, max_len):
    value = data.get(field)
    if not isinstance(value, str):
        raise ValidationError(f"'{field}' is required and must be a string")
    if not (min_len <= len(value) <= max_len):
        raise ValidationError(f"'{field}' must be {min_len}-{max_len} characters")
    return value


def require_object(data):
    if not isinstance(data, dict):
        raise ValidationError("body must be a JSON object")
    return data


def credentials(data, *, strict_password):
    """Registration enforces the password policy; login only bounds length (DoS guard)."""
    require_object(data)
    username = _string(data, "username", 3 if strict_password else 1, 32).strip().lower()
    if strict_password:
        if not USERNAME_RE.match(username):
            raise ValidationError("'username' may only contain letters, digits, . _ -")
        password = _string(data, "password", 8, 128)
    else:
        password = _string(data, "password", 1, 128)  # cap stops huge-input hashing DoS
    return username, password


def record_fields(data):
    require_object(data)
    return _string(data, "title", 1, 200), _string(data, "body", 1, 10_000)
