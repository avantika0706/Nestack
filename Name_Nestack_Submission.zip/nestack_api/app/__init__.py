from flask import Flask, jsonify
from werkzeug.exceptions import HTTPException

from . import auth, db
from .config import load_config
from .routes import bp
from .validation import ValidationError


def create_app(overrides=None):
    app = Flask(__name__)
    app.config.update(load_config(overrides))
    app.teardown_appcontext(db.close_db)
    app.register_blueprint(bp)

    with app.app_context():
        db.init_db()

    @app.errorhandler(ValidationError)
    def _validation(e):
        return jsonify(error=str(e)), 400

    @app.errorhandler(auth.AuthError)
    def _auth(e):
        return jsonify(error=e.message), e.status, e.headers

    @app.errorhandler(HTTPException)
    def _http(e):
        # Oversized body (413) is reported as 400 per the spec; others keep their code.
        code = 400 if e.code == 413 else e.code
        return jsonify(error="request too large" if e.code == 413 else e.name), code

    @app.errorhandler(Exception)
    def _unexpected(_e):
        app.logger.exception("unhandled error")  # details to logs only, never to the client
        return jsonify(error="internal error"), 500

    @app.after_request
    def _headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Cache-Control"] = "no-store"
        return resp

    return app
