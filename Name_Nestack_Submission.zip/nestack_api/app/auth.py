"""Authentication, lockout and authorization logic. No routes here."""
import time
from functools import wraps

from flask import current_app, g, jsonify, request

from . import db, security


class AuthError(Exception):
    def __init__(self, status, message, headers=None):
        self.status, self.message, self.headers = status, message, headers or {}


def login(username, password):
    """Returns a session token, or raises AuthError(401/429)."""
    cfg, now = current_app.config, int(time.time())

    # 1. Lockout is checked BEFORE verifying the password, so even the right password
    #    gets 429 while locked (otherwise the lock doesn't stop guessing).
    failures = db.get_failures(username)
    if failures and failures["locked_until"] > now:
        retry = failures["locked_until"] - now
        raise AuthError(429, "too many failed attempts, try again later",
                        {"Retry-After": str(retry)})

    user = db.get_user_by_username(username)
    # 2. Always do one scrypt verify (dummy hash if no such user): same timing and same
    #    401 whether the username exists or not -> no user enumeration via login.
    ok = security.verify_password(password, user["password_hash"] if user else security.DUMMY_HASH)

    if not (user and ok):
        db.record_failure(username, cfg["MAX_FAILED_LOGINS"], cfg["LOCKOUT_SECONDS"], now)
        raise AuthError(401, "invalid credentials")

    db.clear_failures(username)
    token = security.new_session_token()
    db.create_session(security.token_digest(token), user["id"], now + cfg["SESSION_TTL_SECONDS"])
    return token


def require_auth(view):
    """Proves identity on EVERY request: look up the digest of the presented token server-side."""
    @wraps(view)
    def wrapper(*args, **kwargs):
        header = request.headers.get("Authorization", "")
        scheme, _, token = header.partition(" ")
        if scheme.lower() != "bearer" or not token:
            return jsonify(error="authentication required"), 401
        user = db.get_user_by_session(security.token_digest(token.strip()), int(time.time()))
        if user is None:
            return jsonify(error="invalid or expired session"), 401
        g.user = user
        return view(*args, **kwargs)
    return wrapper


def can_read_record(user, record):
    """The object-level access check. Single place, easy to audit and test."""
    return user["role"] == "admin" or record["owner_id"] == user["id"]
