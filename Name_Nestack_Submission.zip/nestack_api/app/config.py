"""Environment-based configuration. Nothing secret is hard-coded."""
import os


def load_config(overrides=None):
    cfg = {
        "DATABASE_PATH": os.environ.get("DATABASE_PATH", "records.db"),
        "SESSION_TTL_SECONDS": int(os.environ.get("SESSION_TTL_SECONDS", 3600)),
        "MAX_FAILED_LOGINS": int(os.environ.get("MAX_FAILED_LOGINS", 5)),
        "LOCKOUT_SECONDS": int(os.environ.get("LOCKOUT_SECONDS", 900)),
        "MAX_CONTENT_LENGTH": int(os.environ.get("MAX_BODY_BYTES", 65536)),
    }
    if overrides:
        cfg.update(overrides)
    return cfg
