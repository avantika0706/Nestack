"""Storage layer. Every query is parameterised (? placeholders), never string-built."""
import sqlite3
import time
import uuid

from flask import current_app, g

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    created_at    INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
    token_digest TEXT PRIMARY KEY,
    user_id      INTEGER NOT NULL REFERENCES users(id),
    expires_at   INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS login_failures (
    username     TEXT PRIMARY KEY,   -- keyed per ACCOUNT NAME, whether or not it exists
    count        INTEGER NOT NULL,
    locked_until INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS records (
    id         TEXT PRIMARY KEY,     -- random UUID, not guessable/sequential
    owner_id   INTEGER NOT NULL REFERENCES users(id),
    title      TEXT NOT NULL,
    body       TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
"""


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE_PATH"])
        g.db.row_factory = sqlite3.Row
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    get_db().executescript(SCHEMA)
    get_db().commit()


# ---- users ----
def create_user(username, password_hash, role="user"):
    db = get_db()
    cur = db.execute(
        "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
        (username, password_hash, role, int(time.time())))
    db.commit()
    return cur.lastrowid


def get_user_by_username(username):
    return get_db().execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()


# ---- sessions ----
def create_session(digest, user_id, expires_at):
    db = get_db()
    db.execute("INSERT INTO sessions (token_digest, user_id, expires_at) VALUES (?, ?, ?)",
               (digest, user_id, expires_at))
    db.commit()


def get_user_by_session(digest, now):
    return get_db().execute(
        "SELECT u.id, u.username, u.role FROM sessions s JOIN users u ON u.id = s.user_id "
        "WHERE s.token_digest = ? AND s.expires_at > ?", (digest, now)).fetchone()


# ---- login failures ----
def get_failures(username):
    return get_db().execute("SELECT * FROM login_failures WHERE username = ?", (username,)).fetchone()


def record_failure(username, max_failures, lockout_seconds, now):
    db = get_db()
    row = get_failures(username)
    count = (row["count"] if row else 0) + 1
    locked_until = now + lockout_seconds if count >= max_failures else 0
    db.execute(
        "INSERT INTO login_failures (username, count, locked_until) VALUES (?, ?, ?) "
        "ON CONFLICT(username) DO UPDATE SET count = excluded.count, locked_until = excluded.locked_until",
        (username, count, locked_until))
    db.commit()


def clear_failures(username):
    db = get_db()
    db.execute("DELETE FROM login_failures WHERE username = ?", (username,))
    db.commit()


# ---- records ----
def create_record(owner_id, title, body):
    rid = uuid.uuid4().hex
    db = get_db()
    db.execute("INSERT INTO records (id, owner_id, title, body, created_at) VALUES (?, ?, ?, ?, ?)",
               (rid, owner_id, title, body, int(time.time())))
    db.commit()
    return rid


def get_record(record_id):
    return get_db().execute(
        "SELECT id, owner_id, title, body, created_at FROM records WHERE id = ?",
        (record_id,)).fetchone()
