"""HTTP layer only: parse, validate, call auth/db, shape the response."""
import sqlite3

from flask import Blueprint, g, jsonify, request

from . import auth, db, security, validation
from .validation import ValidationError

bp = Blueprint("api", __name__)


def _json_body():
    data = request.get_json(silent=True)  # malformed JSON -> None -> rejected below
    return validation.require_object(data)


@bp.post("/register")
def register():
    data = _json_body()
    # Privilege escalation attempt: role may never come from the client.
    if "role" in data:
        return jsonify(error="role cannot be set by clients"), 403
    username, password = validation.credentials(data, strict_password=True)
    try:
        db.create_user(username, security.hash_password(password), role="user")  # always 'user'
    except sqlite3.IntegrityError:
        return jsonify(error="username unavailable"), 409
    return jsonify(message="registered", role="user"), 201


@bp.post("/login")
def login():
    data = _json_body()
    username, password = validation.credentials(data, strict_password=False)
    token = auth.login(username, password)
    return jsonify(token=token, token_type="Bearer"), 200


@bp.post("/records")
@auth.require_auth
def create_record():
    data = _json_body()
    if "owner_id" in data or "role" in data:
        return jsonify(error="forbidden field"), 403
    title, body = validation.record_fields(data)
    record_id = db.create_record(g.user["id"], title, body)  # owner comes from the session only
    return jsonify(id=record_id), 201


@bp.get("/records/<record_id>")
@auth.require_auth
def get_record(record_id):
    record = db.get_record(record_id)
    # Same 404 for "doesn't exist" and "not yours": no existence oracle for other tenants' ids.
    if record is None or not auth.can_read_record(g.user, record):
        return jsonify(error="not found"), 404
    return jsonify(id=record["id"], title=record["title"], body=record["body"],
                   created_at=record["created_at"]), 200
