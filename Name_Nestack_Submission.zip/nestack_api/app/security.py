"""Crypto primitives only: password hashing and token generation."""
import hashlib
import hmac
import os
import secrets

# scrypt cost parameters (~16 MiB, tens of ms per hash). Stored inside each hash string,
# so they can be raised later without breaking existing users.
_N, _R, _P, _DKLEN = 2**14, 8, 1, 32
_MAXMEM = 64 * 1024 * 1024


def hash_password(password: str) -> str:
    salt = os.urandom(16)  # per-user random salt
    dk = hashlib.scrypt(password.encode(), salt=salt, n=_N, r=_R, p=_P,
                        dklen=_DKLEN, maxmem=_MAXMEM)
    return f"scrypt${_N}${_R}${_P}${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt, dk = stored.split("$")
        if scheme != "scrypt":
            return False
        expected = bytes.fromhex(dk)
        candidate = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt),
                                   n=int(n), r=int(r), p=int(p),
                                   dklen=len(expected), maxmem=_MAXMEM)
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(candidate, expected)  # constant-time compare


# Verified against when a username doesn't exist, so response time doesn't reveal it.
DUMMY_HASH = hash_password("dummy-password-for-timing-equalisation")


def new_session_token() -> str:
    return secrets.token_urlsafe(32)  # 256 bits from the OS CSPRNG


def token_digest(token: str) -> str:
    # Tokens are high-entropy, so a fast hash is fine here (unlike passwords).
    # Only the digest is stored: a DB leak does not yield usable tokens.
    return hashlib.sha256(token.encode()).hexdigest()
