"""Server-side-only admin creation:  python manage.py create-admin <username>
The password is read from the ADMIN_PASSWORD env var or prompted. There is no HTTP path to this."""
import getpass
import os
import sys

from app import create_app, db, security
from app.validation import ValidationError, credentials

if len(sys.argv) != 3 or sys.argv[1] != "create-admin":
    sys.exit("usage: python manage.py create-admin <username>")

password = os.environ.get("ADMIN_PASSWORD") or getpass.getpass("Admin password: ")
try:
    username, password = credentials({"username": sys.argv[2], "password": password}, strict_password=True)
except ValidationError as e:
    sys.exit(f"invalid input: {e}")

app = create_app()
with app.app_context():
    db.create_user(username, security.hash_password(password), role="admin")
print(f"admin '{username}' created")
