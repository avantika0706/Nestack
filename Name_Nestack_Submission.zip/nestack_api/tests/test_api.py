import os
import tempfile
import unittest

from app import create_app, db, security


class ApiTestCase(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.app = create_app({"DATABASE_PATH": self.path, "MAX_FAILED_LOGINS": 5,
                               "LOCKOUT_SECONDS": 900, "TESTING": False})
        self.c = self.app.test_client()

    def tearDown(self):
        os.remove(self.path)

    # helpers
    def register(self, u, p="correct-horse-1"):
        return self.c.post("/register", json={"username": u, "password": p})

    def login(self, u, p="correct-horse-1"):
        return self.c.post("/login", json={"username": u, "password": p})

    def token(self, u):
        self.register(u)
        return self.login(u).get_json()["token"]

    def auth(self, tok):
        return {"Authorization": f"Bearer {tok}"}

    def make_record(self, tok, title="t", body="b"):
        r = self.c.post("/records", json={"title": title, "body": body}, headers=self.auth(tok))
        self.assertEqual(r.status_code, 201)
        return r.get_json()["id"]


class AccessControl(ApiTestCase):
    def test_owner_can_read_own_record(self):
        a = self.token("alice")
        rid = self.make_record(a, "secret", "mine")
        r = self.c.get(f"/records/{rid}", headers=self.auth(a))
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["body"], "mine")

    def test_user_cannot_read_another_users_record(self):
        a, b = self.token("alice"), self.token("bob")
        rid = self.make_record(a, "secret", "alice-only")
        r = self.c.get(f"/records/{rid}", headers=self.auth(b))
        self.assertIn(r.status_code, (403, 404))
        self.assertNotIn(b"alice-only", r.data)

    def test_forbidden_and_missing_are_indistinguishable(self):
        a, b = self.token("alice"), self.token("bob")
        rid = self.make_record(a)
        other = self.c.get(f"/records/{rid}", headers=self.auth(b))
        missing = self.c.get("/records/doesnotexist", headers=self.auth(b))
        self.assertEqual(other.status_code, missing.status_code)
        self.assertEqual(other.get_json(), missing.get_json())

    def test_admin_can_read_any_record(self):
        a = self.token("alice")
        rid = self.make_record(a, "t", "alice-data")
        with self.app.app_context():
            db.create_user("root", security.hash_password("admin-pass-123"), role="admin")
        adm = self.login("root", "admin-pass-123").get_json()["token"]
        r = self.c.get(f"/records/{rid}", headers=self.auth(adm))
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["body"], "alice-data")


class PrivilegeEscalation(ApiTestCase):
    def test_register_with_role_is_refused(self):
        r = self.c.post("/register", json={"username": "mallory", "password": "correct-horse-1",
                                           "role": "admin"})
        self.assertEqual(r.status_code, 403)
        with self.app.app_context():
            self.assertIsNone(db.get_user_by_username("mallory"))

    def test_registered_account_is_always_user(self):
        self.register("carol")
        with self.app.app_context():
            self.assertEqual(db.get_user_by_username("carol")["role"], "user")

    def test_record_create_cannot_set_owner_or_role(self):
        a = self.token("alice")
        r = self.c.post("/records", json={"title": "t", "body": "b", "owner_id": 999},
                        headers=self.auth(a))
        self.assertEqual(r.status_code, 403)


class SessionIntegrity(ApiTestCase):
    def test_missing_forged_and_garbage_tokens_get_401(self):
        self.assertEqual(self.c.get("/records/x").status_code, 401)
        self.assertEqual(self.c.get("/records/x", headers=self.auth("forged")).status_code, 401)
        self.assertEqual(self.c.get("/records/x", headers={"Authorization": "Basic abc"}).status_code, 401)

    def test_expired_session_gets_401(self):
        a = self.token("alice")
        with self.app.app_context():
            db.get_db().execute("UPDATE sessions SET expires_at = 1")
            db.get_db().commit()
        self.assertEqual(self.c.post("/records", json={"title": "t", "body": "b"},
                                     headers=self.auth(a)).status_code, 401)

    def test_tokens_not_stored_in_plaintext(self):
        a = self.token("alice")
        with self.app.app_context():
            rows = db.get_db().execute("SELECT token_digest FROM sessions").fetchall()
        self.assertTrue(all(r["token_digest"] != a for r in rows))


class LoginLockout(ApiTestCase):
    def test_lockout_after_five_failures_returns_429(self):
        self.register("alice")
        for _ in range(5):
            self.assertEqual(self.login("alice", "wrong-password").status_code, 401)
        r = self.login("alice", "wrong-password")
        self.assertEqual(r.status_code, 429)
        self.assertIn("Retry-After", r.headers)

    def test_correct_password_still_blocked_while_locked(self):
        self.register("alice")
        for _ in range(5):
            self.login("alice", "wrong-password")
        self.assertEqual(self.login("alice").status_code, 429)

    def test_lockout_is_per_account_not_per_ip(self):
        self.register("alice")
        self.register("bob")
        for _ in range(5):
            self.login("alice", "wrong-password")
        self.assertEqual(self.login("alice").status_code, 429)
        self.assertEqual(self.login("bob").status_code, 200)  # same client IP, unaffected

    def test_success_resets_counter(self):
        self.register("alice")
        for _ in range(4):
            self.login("alice", "wrong-password")
        self.assertEqual(self.login("alice").status_code, 200)
        for _ in range(4):
            self.assertEqual(self.login("alice", "wrong-password").status_code, 401)

    def test_unknown_user_gets_same_401_as_wrong_password(self):
        self.register("alice")
        a = self.login("alice", "wrong-password")
        b = self.login("nobody", "wrong-password")
        self.assertEqual((a.status_code, a.get_json()), (b.status_code, b.get_json()))


class PasswordStorage(ApiTestCase):
    def test_password_is_salted_scrypt_not_plaintext(self):
        self.register("alice", "correct-horse-1")
        self.register("bob", "correct-horse-1")  # same password
        with self.app.app_context():
            a = db.get_user_by_username("alice")["password_hash"]
            b = db.get_user_by_username("bob")["password_hash"]
        self.assertTrue(a.startswith("scrypt$"))
        self.assertNotIn("correct-horse-1", a)
        self.assertNotEqual(a, b)  # per-user salt -> different hashes for identical passwords


class InputValidation(ApiTestCase):
    def test_bad_inputs_return_400(self):
        tok = self.token("alice")
        h = self.auth(tok)
        cases = [
            self.c.post("/register", data="not json", content_type="application/json"),
            self.c.post("/register", json=["list"]),
            self.c.post("/register", json={"username": 123, "password": "correct-horse-1"}),
            self.c.post("/register", json={"username": "ab", "password": "correct-horse-1"}),
            self.c.post("/register", json={"username": "bad name!", "password": "correct-horse-1"}),
            self.c.post("/register", json={"username": "okname", "password": "short"}),
            self.c.post("/login", json={"username": "alice"}),
            self.c.post("/records", json={"title": "", "body": "b"}, headers=h),
            self.c.post("/records", json={"title": "t" * 201, "body": "b"}, headers=h),
            self.c.post("/records", json={"title": "t", "body": 5}, headers=h),
            self.c.post("/records", json={"title": "t", "body": "x" * 200_000}, headers=h),
        ]
        for r in cases:
            self.assertEqual(r.status_code, 400, r.get_data(as_text=True))

    def test_sql_injection_payloads_are_inert(self):
        a = self.token("alice")
        rid = self.make_record(a)
        r = self.c.get("/records/' OR '1'='1", headers=self.auth(a))
        self.assertEqual(r.status_code, 404)
        r = self.login("alice' --", "x")
        self.assertEqual(r.status_code, 401)
        self.assertEqual(self.c.get(f"/records/{rid}", headers=self.auth(a)).status_code, 200)

    def test_duplicate_username_is_409(self):
        self.register("alice")
        self.assertEqual(self.register("ALICE").status_code, 409)  # case-insensitive


if __name__ == "__main__":
    unittest.main()
