# Secure Records API

Multi-tenant records API: users sign in, create records and read only their own; an admin can read any.
Python 3.10+, Flask, SQLite. **No auth library**: hashing, sessions, lockout and access control are in this repo.

## Run

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # optional; defaults work
export $(grep -v '^#' .env | xargs)   # or set the variables however you prefer
python manage.py create-admin root    # admins are created server-side only
flask --app wsgi run
python -m unittest discover -s tests -t .   # 19 tests
```

```bash
curl -X POST localhost:5000/register -H 'Content-Type: application/json' -d '{"username":"alice","password":"correct-horse-1"}'
curl -X POST localhost:5000/login    -H 'Content-Type: application/json' -d '{"username":"alice","password":"correct-horse-1"}'
curl -X POST localhost:5000/records  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"title":"t","body":"b"}'
curl localhost:5000/records/$ID      -H "Authorization: Bearer $TOKEN"
```

## Layout

| File | Responsibility |
|---|---|
| `app/security.py` | scrypt hashing, token generation (crypto only) |
| `app/db.py` | all SQL, parameterised |
| `app/auth.py` | login + lockout, `require_auth`, `can_read_record` |
| `app/validation.py` | input validation |
| `app/routes.py` | HTTP only |
| `app/config.py` | environment-based config |

## Threat model

### Password storage
scrypt (`n=2^14, r=8, p=1`) with a 16-byte random salt per user, from Python's stdlib. It is deliberately slow and
memory-hard, which makes GPU/ASIC cracking expensive. The salt defeats rainbow tables and means two users with the same
password have different hashes (tested). Parameters are stored in each hash string so they can be raised later.
Comparison uses `hmac.compare_digest`. Passwords are capped at 128 characters so huge inputs can't be used as a CPU DoS.

### Session: opaque server-side token (chosen over JWT)
Login returns 256 random bits (`secrets.token_urlsafe(32)`). The server stores only its SHA-256 digest with the user id and
expiry. **Every** request looks the digest up; no match or expired means 401.
Why not JWT: with a signed token the role/identity lives in the token and can't be revoked before expiry without adding
server state anyway; a signing-key leak lets an attacker mint admin tokens; and the role can be changed in the DB and
takes effect immediately. The cost is one indexed DB lookup per request, which is fine here.
Tokens are high-entropy, so a fast hash is appropriate for them (unlike passwords).

### Per-record access check
`GET /records/:id` loads the record, then `can_read_record(user, record)` returns true only if `user.role == 'admin'` or
`record.owner_id == user.id`. This runs on every read, with the user taken from the session, never from the request.
Not-yours and doesn't-exist both return an identical **404**, so ids can't be probed to learn what exists. Record ids are random
UUIDs, not sequential (defence in depth, not the control). `owner_id` on create comes from the session; a client-supplied
`owner_id` is refused with 403.

### Preventing admin escalation
Role is never read from request data. `/register` always inserts `role='user'` and returns 403 if the body contains `role`.
There is no profile-edit endpoint. Admins exist only via `python manage.py create-admin` (server-side access
required). The DB also has a `CHECK` constraint limiting roles to `user`/`admin`.

### If the users table leaked
**Could recover:** usernames, roles, account creation times. Weak/common passwords could eventually be cracked offline, at
a cost of ~16 MiB and tens of ms per guess per user, because each hash is salted so no work is shared across users.
**Could not recover:** plaintext passwords of strong passwords; session tokens (only digests are stored and the tokens are
256-bit random, so the digests can't be reversed or used to authenticate); anything lets them *forge* a session (there is
no signing key to steal). Sessions table leaked alongside is equally harmless. Records are **not** encrypted at rest,
so a leak of the records table exposes their content; that's a limitation (see below).

### Login brute force
Failures are counted **per account name** (not per IP) in the DB. After 5 failures the account is locked for 15 min and
returns **429 + Retry-After**. The lock is checked *before* verifying the password, so guessing the right one while locked
doesn't help. Counters are also kept for nonexistent usernames, and unknown users run a dummy scrypt verify, so
`401`/`429` behaviour and timing don't reveal whether an account exists. Success resets the counter.

### Input validation / injection
Every field is checked for presence, type and length; bad input gets 400. Malformed JSON, non-object bodies and bodies over
64 KiB also get 400. All SQL uses `?` placeholders. Unhandled exceptions return a generic 500 and log details server-side only.

## Known limitations / trade-offs (honest list)
- **Lockout can be abused to DoS a victim's account** (attacker fails 5 times on purpose). Per-account limiting is what
  the brief requires; mitigations would be exponential backoff, CAPTCHA, or combining with per-IP limits.
- `/register` returns 409 for a taken username, which reveals that it exists. Common trade-off; the alternative is email verification.
- No HTTPS in-app: deploy behind TLS, since bearer tokens are only as safe as the transport.
- Records are not encrypted at rest and there is no logout/token-revocation endpoint (tokens expire after 1 h).
- SQLite and a single process; use Postgres and a shared store for real multi-instance deployment.
- No password-breach checking or MFA.
